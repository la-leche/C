#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <ctype.h>

#define NUMBER_OF_WORDS 20
#define WORTLAENGE 50

char wortfeld[NUMBER_OF_WORDS][WORTLAENGE]
  = {
      "HOCHSEEFRACHTER",
      "STUDIENORDNUNG",
      "FERNSEHEMPFANG",
      "HOFFNUNG",
      "BUNDESTAG",
      "TIEFDRUCKGEBIET",
      "EUROPAMEISTERSCHAFT",
      "GRUNDGESETZ",
      "INVERSIONSWETTERLAGE",
      "BAUMHAUS",
      "REGENSCHAUER",
      "BUNDESVERFASSUNGSGERICHT",
      "GRAUPELSCHAUER",
      "WASSERVERUNREINIGUNG",
      "KLIMAFORSCHUNG",
      "KOMMUNALWAHL",
      "LAGERREGAL",
      "VORLESUNGSVERZEICHNIS",
      "EUROPAPARLAMENT",
      "XYLOPHONSPIELERIN",
    };
